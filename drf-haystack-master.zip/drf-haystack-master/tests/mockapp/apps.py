# -*- coding: utf-8 -*-

from django.apps import AppConfig


class MockappConfig(AppConfig):
    name = "mockapp"
    verbose_name = "Mock Application"

