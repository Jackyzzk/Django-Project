API Docs
========

.. toctree::
   :maxdepth: 4

   drf_haystack
